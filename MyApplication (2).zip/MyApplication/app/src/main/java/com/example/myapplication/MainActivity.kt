package com.example.myapplication
import android.text.Editable
import org.json.JSONObject

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextWatcher
import android.widget.EditText
import android.widget.TextView
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var cityNameEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cityNameEditText = findViewById(R.id.CityName)

        cityNameEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                fetchWeatherData(s.toString())
            }
        })
    }

    private fun fetchWeatherData(cityName: String) {
        val apiKey = "e53301e27efa0b66d05045d91b2742d3"
        val client = OkHttpClient()
        val url = "https://api.openweathermap.org/data/2.5/weather?q=$cityName&appid=$apiKey"
        val request = Request.Builder()
            .url(url)
            .build()

        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                val responseData = response.body?.string()
                val weatherDataList = parseWeatherData(responseData)
                updateUIWithWeatherData(weatherDataList)
            }

            override fun onFailure(call: okhttp3.Call, e: IOException) {
                e.printStackTrace()
            }
        })
    }

    private fun parseWeatherData(responseData: String?): List<WeatherData> {
        val weatherDataList = mutableListOf<WeatherData>()
        responseData?.let {
            try {
                val jsonObject = JSONObject(it)
                val mainObject = jsonObject.getJSONObject("main")
                val windObject = jsonObject.getJSONObject("wind")

                val weatherData = WeatherData(
                    jsonObject.getString("name"),
                    mainObject.getString("temp"),
                    windObject.getString("speed"),
                    windObject.getString("deg"),
                    mainObject.optString("humidity", "N/A"),
                    "N/A",
                    mainObject.optString("pressure", "N/A")
                )
                weatherDataList.add(weatherData)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return weatherDataList
    }


    @SuppressLint("SetTextI18n")
    private fun updateUIWithWeatherData(weatherDataList: List<WeatherData>) {
        runOnUiThread {
            val textView = findViewById<TextView>(R.id.ids)
            if (weatherDataList.isNotEmpty()) {
                val firstWeatherData = weatherDataList.first()
                textView.text = "Station: ${firstWeatherData.station}\n" +
                        "Temperature: ${firstWeatherData.temperature} °C\n" +
                        "Wind Speed: ${firstWeatherData.windSpeed} m/s\n" +
                        "Wind Direction: ${firstWeatherData.windDirection}°\n" +
                        "Humidity: ${firstWeatherData.relativeHumidity ?: "N/A"}%\n" +
                        "Precipitation: ${firstWeatherData.precipitationSum} mm\n" +
                        "Pressure: ${firstWeatherData.pressure ?: "N/A"} hPa"
            } else {
                textView.text = "No weather data available"
            }
        }
    }
}

data class WeatherData(
    val station: String,
    val temperature: String,
    val windSpeed: String,
    val windDirection: String,
    val relativeHumidity: String?,
    val precipitationSum: String,
    val pressure: String?
)
